/* @ds-bundle: {"format":4,"namespace":"E8DesignSystem_56bc8b","components":[{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Card","sourcePath":"components/layout/Card.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Dialog","sourcePath":"components/overlay/Dialog.jsx"},{"name":"SwitchRole","sourcePath":"handoff/SwitchRole.jsx"}],"sourceHashes":{"components/feedback/Badge.jsx":"b1ac3ea930be","components/feedback/Toast.jsx":"940472d0cdba","components/feedback/Tooltip.jsx":"396092c195dd","components/forms/Button.jsx":"c7f9a7b3850b","components/forms/Checkbox.jsx":"3c8b22ef9ac9","components/forms/IconButton.jsx":"3832a8b61da4","components/forms/Input.jsx":"c214400cd30c","components/forms/Radio.jsx":"f243ca37dcc1","components/forms/Select.jsx":"0d8dc6c832a4","components/forms/Switch.jsx":"34de908a871b","components/layout/Card.jsx":"03085e908ecf","components/navigation/Tabs.jsx":"775c7605b8d5","components/overlay/Dialog.jsx":"63104d42c59b","handoff/SwitchRole.jsx":"1876fb909a77"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.E8DesignSystem_56bc8b = window.E8DesignSystem_56bc8b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/feedback/Badge.jsx
try { (() => {
const cfg = {
  success: {
    icon: 'check',
    weight: 'var(--weight-regular)',
    border: 'none'
  },
  warning: {
    icon: 'triangle-alert',
    weight: 'var(--weight-medium)',
    border: 'none'
  },
  error: {
    icon: 'circle-alert',
    weight: 'var(--weight-bold)',
    border: '2px solid var(--color-border-strong)'
  },
  neutral: {
    icon: null,
    weight: 'var(--weight-medium)',
    border: '1px solid var(--color-border)'
  }
};
function Badge({
  status = 'neutral',
  children
}) {
  const c = cfg[status];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: c.weight,
      color: 'var(--color-text-primary)',
      padding: '4px 10px',
      borderRadius: 999,
      border: c.border,
      background: 'var(--color-surface)'
    }
  }, c.icon && /*#__PURE__*/React.createElement("img", {
    src: '../../assets/icons/' + c.icon + '.svg',
    width: 12,
    height: 12,
    alt: ""
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const iconFor = {
  success: 'check',
  warning: 'triangle-alert',
  error: 'circle-alert'
};
function Toast({
  status = 'success',
  message,
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: status === 'error' ? 'var(--weight-bold)' : 'var(--weight-regular)',
      padding: '12px 14px',
      borderRadius: 'var(--radius-md)',
      border: status === 'error' ? '2px solid var(--color-border-strong)' : '1px solid var(--color-border)',
      background: 'var(--color-surface)',
      boxShadow: 'var(--shadow-elevated)',
      maxWidth: 360
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: '../../assets/icons/' + iconFor[status] + '.svg',
    width: 18,
    height: 18,
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      color: 'var(--color-text-primary)'
    }
  }, message), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      padding: 0,
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/x.svg",
    width: 14,
    height: 14,
    alt: "Close"
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  label,
  children
}) {
  const [show, setShow] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-block'
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      bottom: 'calc(100% + 8px)',
      left: '50%',
      transform: 'translateX(-50%)',
      background: 'var(--color-primary-bg)',
      color: 'var(--color-primary-text)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-medium)',
      padding: '6px 10px',
      borderRadius: 'var(--radius-sm)',
      whiteSpace: 'nowrap',
      zIndex: 10
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  children,
  onClick,
  type = 'button'
}) {
  const pad = {
    sm: '6px 12px',
    md: '10px 16px',
    lg: '14px 24px'
  }[size];
  const fontSize = {
    sm: 'var(--text-sm)',
    md: 'var(--text-sm)',
    lg: 'var(--text-base)'
  }[size];
  const base = {
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--weight-semibold)',
    fontSize,
    padding: pad,
    borderRadius: 'var(--radius-sm)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'opacity .12s ease',
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
    lineHeight: 1
  };
  const styles = {
    primary: {
      ...base,
      background: disabled ? 'var(--color-disabled-bg)' : 'var(--color-primary-bg)',
      color: disabled ? 'var(--color-disabled-text)' : 'var(--color-primary-text)'
    },
    secondary: {
      ...base,
      background: 'transparent',
      borderColor: disabled ? 'var(--color-border)' : 'var(--color-secondary-border)',
      color: disabled ? 'var(--color-disabled-text)' : 'var(--color-secondary-text)'
    }
  };
  const [hover, setHover] = React.useState(false);
  const style = {
    ...styles[variant]
  };
  if (hover && !disabled) {
    if (variant === 'primary') style.opacity = .85;else style.background = 'var(--color-secondary-bg-hover)';
  }
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: style,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked = false,
  disabled = false,
  onChange
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '8px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      color: disabled ? 'var(--color-disabled-text)' : 'var(--color-text-primary)',
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: 4,
      border: '1px solid ' + (checked ? 'var(--color-primary-bg)' : 'var(--color-border)'),
      background: checked ? 'var(--color-primary-bg)' : 'var(--color-surface)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      opacity: disabled ? .4 : 1
    }
  }, checked && /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/check.svg",
    width: 12,
    height: 12,
    style: {
      filter: 'invert(1)'
    },
    alt: ""
  })), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      display: 'none'
    }
  }), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function IconButton({
  icon,
  label,
  size = 36,
  disabled = false,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  const style = {
    width: size,
    height: size,
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 'var(--radius-sm)',
    border: '1px solid var(--color-secondary-border)',
    background: hover && !disabled ? 'var(--color-secondary-bg-hover)' : 'transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? .4 : 1
  };
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    style: style,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, /*#__PURE__*/React.createElement("img", {
    src: icon,
    alt: "",
    width: 18,
    height: 18,
    style: {
      display: 'block'
    }
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function Input({
  label,
  placeholder,
  error,
  disabled = false,
  type = 'text',
  value,
  onChange
}) {
  const [focus, setFocus] = React.useState(false);
  const border = error ? 'var(--color-border-strong)' : focus ? 'var(--color-focus-ring)' : 'var(--color-border)';
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      fontFamily: 'var(--font-sans)',
      width: '100%',
      maxWidth: 320
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--color-text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("input", {
    type: type,
    placeholder: placeholder,
    disabled: disabled,
    value: value,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-base)',
      padding: '10px 12px',
      borderRadius: 'var(--radius-sm)',
      border: '1px solid ' + border,
      outline: 'none',
      background: disabled ? 'var(--color-surface-sunken)' : 'var(--color-surface)',
      color: 'var(--color-text-primary)',
      borderWidth: error ? 2 : 1
    }
  }), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-bold)',
      color: 'var(--color-text-primary)'
    }
  }, error));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  label,
  checked = false,
  disabled = false,
  onChange,
  name
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '8px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      color: disabled ? 'var(--color-disabled-text)' : 'var(--color-text-primary)',
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: '50%',
      border: '1px solid ' + (checked ? 'var(--color-primary-bg)' : 'var(--color-border)'),
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      opacity: disabled ? .4 : 1
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: '50%',
      background: 'var(--color-primary-bg)'
    }
  })), /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      display: 'none'
    }
  }), label);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  label,
  options = [],
  value,
  onChange,
  disabled = false
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      fontFamily: 'var(--font-sans)',
      width: '100%',
      maxWidth: 320
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--color-text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("select", {
    value: value,
    onChange: onChange,
    disabled: disabled,
    style: {
      width: '100%',
      appearance: 'none',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-base)',
      padding: '10px 36px 10px 12px',
      borderRadius: 'var(--radius-sm)',
      border: '1px solid var(--color-border)',
      background: disabled ? 'var(--color-surface-sunken)' : 'var(--color-surface)',
      color: 'var(--color-text-primary)'
    }
  }, options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o))), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/chevron-down.svg",
    width: 16,
    height: 16,
    style: {
      position: 'absolute',
      right: 12,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none'
    },
    alt: ""
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  checked = false,
  disabled = false,
  onChange,
  label
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      color: disabled ? 'var(--color-disabled-text)' : 'var(--color-text-primary)',
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange({
      target: {
        checked: !checked
      }
    }),
    style: {
      width: 36,
      height: 20,
      borderRadius: 999,
      background: checked ? 'var(--color-primary-bg)' : 'var(--gray-200)',
      position: 'relative',
      transition: 'background .15s ease',
      opacity: disabled ? .4 : 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: checked ? 18 : 2,
      width: 16,
      height: 16,
      borderRadius: '50%',
      background: 'var(--white)',
      transition: 'left .15s ease'
    }
  })), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/layout/Card.jsx
try { (() => {
function Card({
  elevated = false,
  children,
  padding = 24
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-surface)',
      borderRadius: 'var(--radius-md)',
      border: elevated ? 'none' : '1px solid var(--color-border)',
      boxShadow: elevated ? 'var(--shadow-elevated)' : 'none',
      padding
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Card.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  active,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '24px',
      borderBottom: '1px solid var(--color-border)',
      fontFamily: 'var(--font-sans)'
    }
  }, items.map(item => {
    const isActive = item === active;
    return /*#__PURE__*/React.createElement("button", {
      key: item,
      onClick: () => onChange && onChange(item),
      style: {
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: '10px 2px',
        fontSize: 'var(--text-sm)',
        fontWeight: isActive ? 'var(--weight-semibold)' : 'var(--weight-regular)',
        color: isActive ? 'var(--color-text-primary)' : 'var(--color-text-secondary)',
        borderBottom: isActive ? '2px solid var(--color-text-primary)' : '2px solid transparent',
        marginBottom: '-1px'
      }
    }, item);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Dialog.jsx
try { (() => {
function Dialog({
  open,
  title,
  children,
  onClose
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(10,10,11,.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 100,
      fontFamily: 'var(--font-sans)'
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: 'var(--color-surface)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-elevated)',
      padding: 32,
      width: 400,
      maxWidth: '90vw'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 'var(--text-lg)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--color-text-primary)'
    }
  }, title), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      padding: 0,
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/x.svg",
    width: 18,
    height: 18,
    alt: "Close"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--color-text-secondary)',
      fontSize: 'var(--text-sm)',
      lineHeight: 'var(--leading-normal)'
    }
  }, children)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Dialog.jsx", error: String((e && e.message) || e) }); }

// handoff/SwitchRole.jsx
try { (() => {
const {
  useState
} = React; // Inter font: self-host and add this @font-face once globally (or use Google Fonts):
// @font-face{font-family:'Inter';font-style:normal;font-weight:100 900;font-display:swap;
//   src:url('/fonts/Inter-Variable.woff2') format('woff2');}
const tokens = {
  fontSans: "'Inter',-apple-system,BlinkMacSystemFont,sans-serif",
  gray50: '#f4f4f5',
  gray100: '#e7e7e9',
  gray200: '#d3d3d6',
  gray950: '#0a0a0b',
  border: '#d3d3d6',
  textPrimary: '#0a0a0b',
  textSecondary: '#6b6b72',
  surface: '#ffffff',
  radiusLg: '16px',
  shadowElevated: '0 4px 16px rgba(10,10,11,.12), 0 1px 2px rgba(10,10,11,.08)'
};
const ROLES = ['Admin', 'Videographer', 'Editor', 'Quality Control', 'Scheduler', 'Sales', 'Sales Manager'];
function RoleRow({
  label,
  checked,
  onClick
}) {
  const [hover, setHover] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '8px 10px',
      margin: '0 -10px',
      borderRadius: 8,
      cursor: 'pointer',
      fontSize: 14,
      color: tokens.textPrimary,
      background: hover ? tokens.gray50 : 'transparent'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: '50%',
      border: `1px solid ${checked ? tokens.gray950 : tokens.border}`,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: '50%',
      background: tokens.gray950
    }
  })), label);
}
function SwitchRole({
  userName = 'Eric Davis',
  icon = '/assets/icons/arrow-left-right.svg'
}) {
  const [open, setOpen] = useState(false);
  const [role, setRole] = useState('Admin');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'inline-block',
      fontFamily: tokens.fontSans
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(v => !v),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      cursor: 'pointer',
      background: 'none',
      border: 'none',
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      borderRadius: '50%',
      background: tokens.gray100,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: icon,
    width: 16,
    height: 16,
    alt: ""
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: tokens.textPrimary
    }
  }, "Switch Role")), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(100% + 12px)',
      right: 0,
      width: 280,
      background: tokens.surface,
      border: `1px solid ${tokens.border}`,
      borderRadius: tokens.radiusLg,
      boxShadow: tokens.shadowElevated,
      overflow: 'hidden',
      zIndex: 50
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '18px 20px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 38,
      height: 38,
      borderRadius: '50%',
      background: tokens.gray100,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: icon,
    width: 16,
    height: 16,
    alt: ""
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 14,
      color: tokens.textPrimary
    }
  }, userName), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: tokens.textSecondary,
      marginTop: 2
    }
  }, "Current: ", role))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: `1px solid ${tokens.border}`
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 20px 14px',
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, ROLES.map(r => /*#__PURE__*/React.createElement(RoleRow, {
    key: r,
    label: r,
    checked: role === r,
    onClick: () => {
      setRole(r);
      setOpen(false);
    }
  })))));
}

// Usage: <SwitchRole userName="Eric Davis" icon="/assets/icons/arrow-left-right.svg" />
Object.assign(__ds_scope, { SwitchRole });
})(); } catch (e) { __ds_ns.__errors.push({ path: "handoff/SwitchRole.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.SwitchRole = __ds_scope.SwitchRole;

})();
