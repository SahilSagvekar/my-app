# E8 Design System

E8 Productions, LLC is a full-service media company helping small businesses with social media — video production, content deliverables, and analytics tracking, run through a review/QC/approval workflow.

**Sources provided:**
- `uploads/E8 Style Guide.pdf` — 20-page brand style guide (colors, type, logo usage, voice, UI components, spacing, iconography, social/export specs). No Figma link, codebase, or product screenshots were provided, so this system is built directly from the style guide rather than an existing product's source. If a codebase or Figma file exists for E8's actual product UI, attach it and this system should be revisited — the components below are an original neutral-palette set built to the guide's rules, not a recreation of a real screen.
- `uploads/e8-logo.svg` — the only logo asset provided (single black mark). A white variant (`assets/e8-logo-white.svg`) was derived by recoloring the same path, per the guide's own black/white rule — no new mark was drawn.

## Content fundamentals

**Voice: technical & precise.** Copy leads with process and accountability (QC, review, tracking), never with sales adjectives. State what happens, not how great it is.

- Active voice, present tense.
- Specific numbers over vague claims.
- Examples from the guide: "Every deliverable passes QC before you see it." / "We review videos, approve deliverables, and track analytics — one system, full accountability."
- In practice: Button — "Review deliverable". Error — "Upload failed — retry in 30s". Email subject — "Your video is ready for review".
- Naming: always "E8" or "E8 Productions, LLC". Never "E8 Prod", "E8Productions", "E8 Media", or similar.
- No emoji anywhere in the guide's examples.

## Visual foundations

- **Color:** strict neutral — black, white, and a 12-step gray scale (`--gray-0` to `--gray-950`). No hue is introduced anywhere without sign-off. The brand differentiates through content, motion, and craft, not color.
- **Type:** Inter only, every weight (400–800), across web, app, and print. Hierarchy comes from weight and size, never a second family.
- **Spacing:** 8px base unit for every margin/padding/gap; 4px allowed only for tight text spacing.
- **Structure:** radius (8/12/16px) and one approved elevation shadow are the only two structural effects. No gradients, no colored borders, no drop-shadowed logos.
- **Backgrounds:** flat neutral surfaces. No imagery, patterns, textures, or gradients seen in the guide.
- **Animation:** not specified in the guide. Treat as minimal/none until product motion is documented — state changes shift opacity/weight, not easing or transforms.
- **Hover state:** primary buttons drop to 85% opacity; secondary/outline elements gain a light-gray (`--gray-50`) fill. Never a color or darker/lighter hue shift.
- **Press/disabled state:** disabled locks to `--gray-100` background / `--gray-300` text — again weight/opacity, not color.
- **Borders:** 1px `--gray-200` by default; error states use a 2px near-black border instead of a color change.
- **Shadows:** one elevation shadow (soft, neutral, low-opacity black) — used sparingly, e.g. modals and elevated cards. No inner shadows, no glow except the video-caption treatment below.
- **Status (success/warning/error):** never red/green. Signaled by icon shape (check / outline triangle / filled icon), font weight, and border weight only.
- **Video captions:** short-form on-screen text is Inter ExtraBold, all caps, 1–2 words, white with a 2px black stroke and a soft black glow (16px blur @85% + 6px blur @90%).
- **Transparency/blur:** only used for the modal backdrop (50% black). No frosted-glass/blur effects seen.
- **Imagery:** none provided in the guide — no product photography or illustration style to reference.
- **Corner radii:** 8px (buttons, small controls), 12px (cards, toasts), 16px (dialogs).
- **Cards:** either a plain 1px `--gray-200` border (default) or the single approved shadow with no border (elevated) — never both, never colored.

## Iconography

The guide specifies a spec (24×24px grid, 1.5px stroke, outline-only, 2px corner radius) but provides no icon files. No CDN or icon font was named, so icons were substituted from **Lucide** (closest match: outline-only, similar stroke weight, MIT-licensed) and copied locally into `assets/icons/` with stroke-width adjusted to 1.5px. **This is a substitution — confirm before shipping if E8 has an existing icon set.** No emoji or unicode icons are used anywhere in the guide.

## Fonts

Inter is specified but no font files were provided. **Substituted from Google Fonts** (variable font, weights 400–800) and self-hosted at `assets/fonts/Inter-Variable.woff2`. Flagging per instructions — if E8 licenses a specific Inter build, replace this file.

## Index

- `styles.css` — root stylesheet, imports everything below.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css` (radius/shadow/opacity), `fonts.css` (`@font-face`).
- `assets/` — `e8-logo.svg`, `e8-logo-white.svg`, `fonts/Inter-Variable.woff2`, `icons/*.svg` (Lucide, substituted).
- `guidelines/` — foundation specimen cards: neutral & semantic colors, type weights & scale, video captions, spacing scale, radius & elevation, status states, logo usage & misuse, iconography, voice & tone.
- `components/` — reusable primitives, grouped by concern:
  - `forms/` — Button, IconButton, Input, Checkbox, Radio, Switch, Select
  - `feedback/` — Badge, Toast, Tooltip
  - `navigation/` — Tabs
  - `layout/` — Card
  - `overlay/` — Dialog

### Intentional additions
No product source defined a component inventory, so the above is a standard set sized to what the guide's UI-components page (buttons, states) and error/success page implied. All follow the guide's neutral, non-color status system.

## Caveats & next steps

- No product codebase, Figma file, or app/website screenshots were provided, so there are **no UI kits** in this system — only foundations and generic components. If E8 has an actual product (client dashboard, mobile app, marketing site), attach it and I'll build kit(s) recreating those real screens.
- Icons and the Inter font file are **substituted**, not sourced from E8 — see above.
- Animation, imagery style, and press-state specifics aren't in the style guide — the choices above are conservative defaults; correct me if E8 has documented motion/photography guidelines elsewhere.

**Ask:** tell me what to fix — wrong component set, missing states, a real product to build UI kits from — and I'll iterate.
