# Handoff: Host Portal (talent-facing)

## Overview
A separate portal for the **host / talent** themselves — not an admin view. A host signs in and sees only their own bookings, payments, and paperwork. There is no in-app messaging (deliberately cut): coordination happens through the booking details and paperwork status, and E8 reaches hosts by their existing channels.

Three sections: **My Shoots**, **Payments**, **Employment Information**.

This is a sibling to the Videographer Portal and shares its chrome, spacing, and card language. It is the third portal in the family (Admin, Videographer, Host).

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing intended look and behavior, not production code to copy. Recreate these designs in the app's existing environment (the current portal stack, its component library and routing), following established patterns.

`Host Portal.dc.html` is a single-file prototype: all views live in one file with a `view` state variable. In the real app these are separate routes.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, and states come from the bound **E8 Design System**. Use the real E8 component library (Button, Badge, Select, Input, Tabs, Dialog, Card) rather than re-styling raw elements.

Two deliberate deviations from the current live app, both flagged for product:
1. **Status is neutral, not colored.** E8's system signals status through icon + weight + border, never red/green. Badges here follow E8. The live app uses colored pills — one component swap if product prefers that.
2. **Sign out is not red.** Same reason. The live app's menu shows it in red.

## App Chrome (matches the Editor / Videographer portals)
Full-width top bar, then sidebar + content below it.

**Top bar** — 72px tall, 1px bottom border, 24px horizontal padding, `z-index` above content:
- Left: E8 mark (26px tall) + portal name, `--text-lg` / 700.
- Center: search field — `--gray-50` fill, 999px radius, 11px/18px padding, search icon at 50% opacity, placeholder "Search shoots, payments, forms...". `flex: 1 1 220px; max-width: 620px`. (Non-functional in the prototype.)
- Right: role switcher — 34px circle (`--gray-50`) + "Viewing: Host" (`--text-base` / 700); then the user chip — 38px black circle avatar + name (`--text-sm` / 600), 999px radius, hover `--gray-50`.
- User menu (click the chip): 320px panel, 12px radius, 1px border, `--shadow-elevated`, positioned `top: 66px; right: 24px`. Rows: avatar + name + email header; **Profile** (navigates to Employment Information); **Sign out** (600 weight).

**Sidebar** — 240px (`flex: 0 1 240px; min-width: 180px`), 1px right border, 16px/12px padding, 2px row gap. Rows: 11px/14px padding, 8px radius, 14px text, 16px icon at 80% opacity, 12px gap. Active row: `--gray-950` fill, white text, 600 weight, icon `filter: invert(1)`. Nav: **My Shoots** (calendar), **Payments** (send), **Employment Information** (check). Footer label "Host Portal v1.0" (12px, `--color-text-tertiary`), pushed down with `margin-top: auto`.

**Content column** — `flex: 1 1 520px`, 32px padding, `max-width` 960px (shoots/payments) or 1100px (employment), 16–24px section gaps.

## Screens / Views

### 1. My Shoots (`view: 'shoots'`)
- **Header**: `My Shoots` (32px/700) + sub line computed from state — "2 confirmed shoots, next on Sep 9, 2026", or "No confirmed shoots on the books".
- **Booking invitations** (only when any exist) — heading "n bookings need your response". Card uses `--color-border-strong` (1px) to distinguish it: date block on the left (month label 11px uppercase `letter-spacing:.04em` tertiary, day 32px/700), client name (16px/700), meta line `date · call · location · role`, rate at right (label 11px uppercase + value 20px/700). Footer strip (`--gray-50`, 1px top border, 12px/18px padding): respond-by note left; **Can't make it** (secondary) and **Accept booking** (primary) right.
- **Confirmed (n)** — same card, normal border, with a status Badge next to the client name. Adds a meta grid `repeat(auto-fit, minmax(150px,1fr))`: Call time, Location, Wardrobe, Videographer. Footer strip: payment line (e.g. "$450 · Due Sep 16, 2026" or "$425 paid Aug 21, 2026") + **Shoot details** (secondary).
- **Past shoots (n)** — compact single-line rows: date, client + status badge, rate, payment note.
- Removed on request: the "n forms need your attention" paperwork banner that previously sat at the top of this page. The same status now lives only on Employment Information.

### 2. Shoot Details modal
620px wide, 16px radius, `--shadow-elevated`, scrolls internally. Header "Shoot details" + X. Body: client (18px/700) and `date · call` line; a `repeat(auto-fit, minmax(160px,1fr))` grid of label/value pairs — Location, Your role, Wardrobe, Videographer, Your rate, Payment; then a `--gray-50` box (1px border, 12px radius, 16px padding) headed "Notes from E8" with the shoot notes (falls back to "No additional notes for this shoot."). Footer: Close (secondary).

### 3. Payments (`view: 'payments'`)
- **Header**: `Payments` + "What E8 has paid you and what is still coming".
- **Stat tiles**, grid `repeat(auto-fit, minmax(180px,1fr))`, 12px gap; each 1px border, 12px radius, 16px/18px padding — label 11px uppercase tertiary, value `--text-xl`/700, note 12px secondary:
  - Paid this year — total of `status: 'paid'`, note = count of payments received.
  - Coming to you — total of everything not paid, note = next payment's label and date.
  - Shoots worked — count of completed bookings, note "Since January 2026".
- **Payout line**: 1px border card — "Payouts go to your Zelle at (214) 555-0148. E8 pays within 7 days of a completed shoot." + **Change payout method** (secondary, → Employment Information).
- **Payment history**: "Payment history" label + a 170px status filter (All payments / Awaiting payment / Scheduled / Paid). Rows: label + status Badge, meta (`Sent <date> · <method>` when paid, otherwise `Due <date> · <method>`), amount `--text-base`/700 right-aligned, and a 140px **View receipt** / **View details** button.
- **Tax year note** at the bottom, above a 1px top border: over $600 → "…E8 will issue a 1099-NEC in January — make sure your W-9 and mailing address are current."; under → "A 1099-NEC is issued once you pass $600 for the year."

### 4. Employment Information (`view: 'employment'`)
Built on the framework of the app's existing Employment Information page: page title + sub "View your employment details, tax forms and leave requests", a 1px divider, then a stack of full-width section cards. Each card: 1px `--color-border`, 12px radius, 20px/24px padding, 16px internal gap, and a header row of `16px icon (75% opacity) + section title (--text-sm / 600)`. Field pairs are label (12px secondary) over value (14px/600) in a `repeat(auto-fit, minmax(220px,1fr))` grid with 20px/24px gaps. Sections in order:

1. **Contractor Profile** (user icon) — 64px avatar circle, name (16px/700), role; then Email, Phone, Status, Mailing address.
2. **Engagement Details** (settings icon) — Classification ("Independent contractor (1099)"), Standard rate, Shoots this year, Paid this year. All derived from state.
3. **Tax Forms & Paperwork** (check icon) — a status strip (1px `--color-border-strong`, 8px radius, 14px/16px padding) with a triangle-alert or check icon, the blocking sentence, and "n of 4 complete"; then one row per form (1px border, 8px radius, 14px/16px padding): name + status Badge, description and updated date, and a 140px action button. Forms: **Form W-9**, **Direct deposit authorization**, **Photo ID**, **Talent release and agreement**. Statuses: `on-file` → "On file" (success, View, secondary); `missing` → "Action needed" (error, Upload, **primary**); `expired` → "Expired" (warning, Re-upload, primary); `submitted` → "Under review" (warning, Replace, secondary).
4. **My Documents** (image icon) — year-end 1099s. 2025 downloadable; 2026 disabled with "Available January 2027 · $1,750 so far" or "Not required yet · …" depending on the $600 threshold.
5. **Payout Method** (send icon) — editable E8 Inputs: Full legal name, Phone, Email, Mailing address, Payout method (Select: Zelle / ACH direct deposit / Check / Cash App), Payout account. Below: a read-only Standard rate card noting "Set by E8. Per-shoot rates are shown on each booking." Then **Save changes** (primary) with a "Saved" confirmation string beside it.
6. **Unavailability** (calendar icon) — explanation + **Request time off →** (primary).
7. **Time Off Requests** (ellipsis icon) — summary "n pending, m approved"; rows with the date range, status Badge (Approved / Awaiting approval / Not approved), reason and submitted date, plus an underlined **Cancel request** on pending items only.

### 5. Upload Form modal
520px. Title = the form's name. Body: the form description plus "E8 reviews submissions within one business day."; dashed `--color-border-strong` drop area (12px radius, 28px padding) with "Drop a PDF or photo here" and **Choose file**; the picked filename appears below. Footer: Cancel / **Submit form** — submitting moves that form to `submitted` ("Under review", updated "Submitted <date> — awaiting review").

### 6. Request Time Off modal
520px. Body: note that E8 will not offer shoots on these dates and that requests covering a confirmed booking need approval; From / To date Inputs in a `minmax(180px,1fr)` grid; Reason Input. Footer: Cancel / **Submit request** — appends a `pending` request.

## Interactions & Behavior
- Sidebar nav switches views; the active row is computed from `view` (fill, text color, and icon invert).
- User chip toggles the menu; Profile navigates to Employment Information and closes the menu.
- Accept booking → `confirmed` (moves into the Confirmed list). Can't make it → `declined` (moves to Past).
- Shoot details opens the modal for that booking.
- Form action buttons open the upload modal for that form; submitting sets `submitted`.
- Save changes on Payout Method sets a "Saved" note; editing any field clears it.
- Request time off appends a pending request; Cancel request removes it.
- Payment filter narrows the history list; all stat tiles and notes recompute from the payment list.
- Hover: primary buttons drop to 85% opacity; secondary/outline gain `--gray-50`; nav rows and clickable rows go to `--gray-50`.
- Modals close on backdrop click and on X.
- Responsive: top bar, sidebar, stat grids, meta grids, and every card row wrap. Fixed widths are limited to the 240px sidebar, the 140–170px button/select columns, and modal panels.

## State Management
Prototype state (rename to fit real models):
- `view`: `'shoots' | 'payments' | 'employment'`
- `me`: `{ name, role, phone, email, city, rate, payout, payoutAccount }` — the signed-in host
- `forms`: `{ w9, dd, id, release }`, each `{ status: 'on-file'|'missing'|'expired'|'submitted', updated }`
- `bookings[]`: `{ id, client, month, day, when, call, location, role, wardrobe, shooter, rate, status: 'confirmed'|'invited'|'completed'|'declined', notes }`
- `payments[]`: `{ id, bookingId, label, date, amount, method, status: 'paid'|'pending'|'scheduled' }`
- `leaves[]`: `{ id, range, reason, status: 'approved'|'pending'|'denied', submitted }`
- UI-only: `payFilter`, `detailId`, `uploadKey`, `pickedFile`, `leaveOpen`, `leaveForm`, `menuOpen`, `profileSaved`

Derived, never stored: paid YTD, outstanding total, next payment, completed-shoot count, form issue count, 1099 threshold state, all headings and summary sentences.

Data needs: current host profile; list bookings for the signed-in host; accept/decline a booking; list payments with status; list/upload employment documents (with a review state); list/create/cancel time-off requests; update profile and payout details. Permission model matters here — a host must only ever read their own records.

## Design Tokens
All from the E8 Design System stylesheets — reference the tokens, don't hardcode.
- Neutrals: `--gray-950 #0a0a0b`, `--gray-900 #131316`, `--gray-800 #222225`, `--gray-700 #38383d`, `--gray-600 #505056`, `--gray-500 #6b6b72`, `--gray-400 #8a8a91`, `--gray-300 #b0b0b5`, `--gray-200 #d3d3d6`, `--gray-100 #e7e7e9`, `--gray-50 #f4f4f5`, `--white #ffffff`
- Roles: `--color-surface` white, `--color-border` gray-200, `--color-border-strong` gray-800, `--color-text-primary` gray-950, `--color-text-secondary` gray-600, `--color-text-tertiary` gray-400, primary fill gray-950 (hover 85% opacity), secondary hover gray-50, disabled bg gray-100 / text gray-300
- Type: Inter only. `--text-xs 12`, `--text-sm 14`, `--text-base 16`, `--text-lg 20`, `--text-xl 24`, `--text-2xl 32`. Weights 400/500/600/700. Line-height 1.15 headings, 1.5–1.6 body. Micro-labels: 11px, uppercase, `letter-spacing:.04em`, tertiary.
- Spacing: 8px base (4px only for tight text). Used: 4, 6, 8, 10, 12, 14, 16, 18, 20, 24, 32.
- Radius: 8px controls and inner rows, 12px cards, 16px dialogs, 999px pills / search field / avatars.
- Elevation: single `--shadow-elevated`, dialogs and the user menu only. Modal backdrop `rgba(10,10,11,.5)`. No gradients, no glow.
- Control sizing: buttons 40px default / 36px `size="sm"`; paired select+button rows are forced to a matching 40px height and fixed width (see the `[data-equal-controls]` helper in the prototype's `<style>` block).

## Assets
- Icons: Lucide outline set copied from the E8 system into `assets/icons/` (24px grid, 1.5px stroke) — `calendar, check, chevron-down, circle-alert, ellipsis, image, plus, search, send, settings, triangle-alert, user, video, x`. **Substituted, not E8-authored** — swap for the app's real icon set. Note the live app uses a briefcase, mail, phone, clock, file, and sign-out glyph that this set lacks; those sections currently reuse the closest available icon.
- Avatars: the prototype draws a neutral circle with a user glyph. The live app shows the host's photo — wire that up.
- Logo: `assets/e8-logo.svg`.
- Fonts: Inter variable, self-hosted by the design system.

## Files
- `Host Portal.dc.html` — the host portal prototype (all views, state, interactions). Design reference only.
- `assets/` — icons and logo used by the prototype.
- `_ds/e8-design-system-.../` — E8 tokens (`tokens/*.css`), `styles.css`, and the component bundle the prototype loads. Use the real E8 library in the app.

## Open questions for product
1. Do hosts accept or decline bookings themselves, or does E8 assign and the host only sees the result? The invitation flow assumes the former.
2. Is payment status entered manually by E8, or synced from a payment processor? The prototype assumes manual entry, host-read-only.
3. Should a host be able to change their own payout method without re-verification?
4. Keep E8's neutral status badges and neutral Sign out, or match the live app's colored pills and red Sign out?
5. Does the top-bar search need to work in this portal, and across what — shoots, payments, documents?
